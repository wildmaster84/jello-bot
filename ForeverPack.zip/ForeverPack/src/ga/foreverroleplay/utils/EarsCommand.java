package ga.foreverroleplay.utils;

import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;

import ga.foreverroleplay.GUI.EarsMenu;
import ga.foreverroleplay.foreverpack.Main;

public class EarsCommand implements CommandExecutor {
	private Main plugin;
	
	public EarsCommand(Main plugin ) {
		this.plugin = plugin;
		plugin.getCommand("ears").setExecutor(this);
	}

	@Override
	public boolean onCommand(CommandSender sender, Command cmd, String label, String[] args) {
		if (!(sender instanceof Player)) {
			return true;
		}
		
		Player p = (Player) sender;
		if (p.hasPermission("foreverpack.GUI")) {
			p.openInventory(EarsMenu.GUI(p));
		}
		
		return false;
	}
	

}

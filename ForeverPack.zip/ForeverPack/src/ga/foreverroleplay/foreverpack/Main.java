package ga.foreverroleplay.foreverpack;


import org.bukkit.plugin.java.JavaPlugin;

import ga.foreverroleplay.GUI.*;
import ga.foreverroleplay.utils.*;
import ga.foreverroleplay.utils.Listeners.*;

public class Main extends JavaPlugin {
	
	@Override 
	public void onEnable() {
		this.saveConfig();
		new EarsCommand(this);
		new HatsCommand(this);
		new HatCommand(this);
		new InventoryClickListener(this);
		EarsMenu.initialize();
		EarsMenu2.initialize();
		HatsMenu.initialize();
		HatsMenu2.initialize();
	}
    public void onDisable() {
		
	}

}

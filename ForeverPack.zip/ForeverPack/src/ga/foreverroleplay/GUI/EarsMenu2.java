package ga.foreverroleplay.GUI;


import org.bukkit.Bukkit;
import org.bukkit.entity.Player;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.ItemStack;

import ga.foreverroleplay.utils.utils;

public class EarsMenu2 {
	
	public static Inventory inv;
	public static String inventory_name;
	public static int inv_rows = 6 * 9;
	
	public static void initialize() {
		inventory_name = utils.chat("&8Ears  (Page 2)");
		
		inv = Bukkit.createInventory(null, inv_rows);
	}
	public static Inventory GUI(Player p) {
		Inventory toReturn = Bukkit.createInventory(null, inv_rows, inventory_name);
		//Add inv items here!
		
		// Loop Item
		utils.createItem(inv, 290, 46, 1, 1, "&aEars 46", "");
		utils.createItem(inv, 290, 47, 1, 2, "&aEars 47", "");
		utils.createItem(inv, 290, 48, 1, 3, "&aEars 48", "");
		utils.createItem(inv, 290, 49, 1, 4, "&aEars 49", "");
		utils.createItem(inv, 290, 50, 1, 5, "&aEars 50", "");
		utils.createItem(inv, 290, 51, 1, 6, "&aEars 51", "");
		utils.createItem(inv, 290, 52, 1, 7, "&aEars 52", "");
		utils.createItem(inv, 290, 53, 1, 8, "&aEars 53", "");
		utils.createItem(inv, 290, 54, 1, 9, "&aEars 54", "");
		utils.createItem(inv, 290, 55, 1, 10, "&aEars 55", "");
		utils.createItem(inv, 290, 56, 1, 11, "&aEars 56", "");
		utils.createItem(inv, 290, 57, 1, 12, "&aEars 57", "");
		utils.createItem(inv, 290, 58, 1, 13, "&aEars 58", "");
		utils.createItem(inv, 290, 59, 1, 14, "&aEars 59", "");
		utils.createItem(inv, 290, 60, 1, 15, "&aEars 60", "");
		utils.createItem(inv, 290, 61, 1, 16, "&aEars 61", "");
		utils.createItem(inv, 290, 62, 1, 17, "&aEars 62", "");
		utils.createItem(inv, 290, 63, 1, 18, "&aEars 63", "");
		utils.createItem(inv, 290, 64, 1, 19, "&aEars 64", "");
		utils.createItem(inv, 290, 65, 1, 20, "&aEars 65", "");
		utils.createItem(inv, 290, 66, 1, 21, "&aEars 66", "");
		utils.createItem(inv, 290, 67, 1, 22, "&aEars 67", "");
		utils.createItem(inv, 290, 68, 1, 23, "&aEars 68", "");
		utils.createItem(inv, 290, 69, 1, 24, "&aEars 69", "");
		utils.createItem(inv, 290, 70, 1, 25, "&aEars 70", "");
		utils.createItem(inv, 290, 71, 1, 26, "&aEars 71", "");
		utils.createItem(inv, 290, 72, 1, 27, "&aEars 72", "");
		utils.createItem(inv, 290, 73, 1, 28, "&aEars 73", "");
		utils.createItem(inv, 290, 74, 1, 29, "&aEars 74", "");
		utils.createItem(inv, 290, 75, 1, 30, "&aEars 75", "");
		utils.createItem(inv, 290, 76, 1, 31, "&aEars 76", "");
		utils.createItem(inv, 290, 77, 1, 32, "&aEars 77", "");
		utils.createItem(inv, 290, 78, 1, 33, "&aEars 78", "");
		utils.createItem(inv, 290, 79, 1, 34, "&aEars 79", "");
		utils.createItem(inv, 290, 80, 1, 35, "&aEars 80", "");
		utils.createItem(inv, 290, 81, 1, 36, "&aEars 81", "");
		utils.createItem(inv, 290, 82, 1, 37, "&aEars 82", "");
		utils.createItem(inv, 290, 83, 1, 38, "&aEars 83", "");
		utils.createItem(inv, 290, 84, 1, 39, "&aEars 84", "");
		utils.createItem(inv, 290, 85, 1, 40, "&aEars 85", "");
		utils.createItem(inv, 290, 86, 1, 41, "&aEars 86", "");
		utils.createItem(inv, 290, 87, 1, 42, "&aEars 87", "");
		utils.createItem(inv, 290, 88, 1, 43, "&aEars 88", "");
		utils.createItem(inv, 290, 89, 1, 44, "&aEars 89", "");
		utils.createItem(inv, 290, 90, 1, 45, "&aEars 90", "");
		
		// Next Page		
		utils.createItem(inv, 339, 0, 1, 46, "&aPage 1", "");
		
		
		toReturn.setContents(inv.getContents());
		
		return toReturn;
	}
	
	public static void clicked(Player p, int slot, ItemStack clicked, Inventory inv) {
		if (clicked.getItemMeta().getDisplayName().equalsIgnoreCase(utils.chat("&aPage 1"))) {
			p.closeInventory();
			p.openInventory(EarsMenu.GUI(p));
		}
		if (!clicked.getItemMeta().getDisplayName().equalsIgnoreCase(utils.chat("&aPage 1"))) {
			p.getInventory().setHelmet(inv.getItem(slot));
			p.closeInventory();
			p.sendMessage(utils.chat("&8[&eEars&8] &7> &aSelected ") + clicked.getItemMeta().getDisplayName());
		}	}

}

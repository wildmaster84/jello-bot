package ga.foreverroleplay.GUI;

import org.bukkit.Bukkit;
import org.bukkit.entity.Player;
import org.bukkit.inventory.*;

import ga.foreverroleplay.utils.utils;

public class HatsMenu {
	
	public static Inventory inv;
	public static String inventory_name;
	public static int inv_rows = 6 * 9;
	
	public static void initialize() {
		inventory_name = utils.chat("&8Hats  (Page 1)");
		
		inv = Bukkit.createInventory(null, inv_rows);
	}
	public static Inventory GUI(Player p) {
		Inventory toReturn = Bukkit.createInventory(null, inv_rows, inventory_name);
		//Add inv items here!
		
		utils.createItem(inv, 291, 1, 1, 1, "&aHat 1", "");
		utils.createItem(inv, 291, 2, 1, 2, "&aHat 2", "");
		utils.createItem(inv, 291, 3, 1, 3, "&aHat 3", "");
		utils.createItem(inv, 291, 4, 1, 4, "&aHat 4", "");
		utils.createItem(inv, 291, 5, 1, 5, "&aHat 5", "");
		utils.createItem(inv, 291, 6, 1, 6, "&aHat 6", "");
		utils.createItem(inv, 291, 7, 1, 7, "&aHat 7", "");
		utils.createItem(inv, 291, 8, 1, 8, "&aHat 8", "");
		utils.createItem(inv, 291, 9, 1, 9, "&aHat 9", "");
		utils.createItem(inv, 291, 10, 1, 10, "&aHat 10", "");
		utils.createItem(inv, 291, 11, 1, 11, "&aHat 11", "");
		utils.createItem(inv, 291, 12, 1, 12, "&aHat 12", "");
		utils.createItem(inv, 291, 13, 1, 13, "&aHat 13", "");
		utils.createItem(inv, 291, 14, 1, 14, "&aHat 14", "");
		utils.createItem(inv, 291, 15, 1, 15, "&aHat 15", "");
		utils.createItem(inv, 291, 16, 1, 16, "&aHat 16", "");
		utils.createItem(inv, 291, 17, 1, 17, "&aHat 17", "");
		utils.createItem(inv, 291, 18, 1, 18, "&aHat 18", "");
		utils.createItem(inv, 291, 19, 1, 19, "&aHat 19", "");
		utils.createItem(inv, 291, 20, 1, 20, "&aHat 20", "");
		utils.createItem(inv, 291, 21, 1, 21, "&aHat 21", "");
		utils.createItem(inv, 291, 22, 1, 22, "&aHat 22", "");
		utils.createItem(inv, 291, 23, 1, 23, "&aHat 23", "");
		utils.createItem(inv, 291, 24, 1, 24, "&aHat 24", "");
		utils.createItem(inv, 291, 25, 1, 25, "&aHat 25", "");
		utils.createItem(inv, 291, 26, 1, 26, "&aHat 26", "");
		utils.createItem(inv, 291, 27, 1, 27, "&aHat 27", "");
		utils.createItem(inv, 291, 28, 1, 28, "&aHat 28", "");
		utils.createItem(inv, 291, 29, 1, 29, "&aHat 29", "");
		utils.createItem(inv, 291, 30, 1, 30, "&aHat 30", "");
		utils.createItem(inv, 291, 31, 1, 31, "&aHat 31", "");
		utils.createItem(inv, 291, 32, 1, 32, "&aHat 32", "");
		utils.createItem(inv, 291, 33, 1, 33, "&aHat 33", "");
		utils.createItem(inv, 291, 34, 1, 34, "&aHat 34", "");
		utils.createItem(inv, 291, 35, 1, 35, "&aHat 35", "");
		utils.createItem(inv, 291, 36, 1, 36, "&aHat 36", "");
		utils.createItem(inv, 291, 37, 1, 37, "&aHat 37", "");
		utils.createItem(inv, 291, 38, 1, 38, "&aHat 38", "");
		utils.createItem(inv, 291, 39, 1, 39, "&aHat 39", "");
		utils.createItem(inv, 291, 40, 1, 40, "&aHat 40", "");
		utils.createItem(inv, 291, 41, 1, 41, "&aHat 41", "");
		utils.createItem(inv, 291, 42, 1, 42, "&aHat 42", "");
		utils.createItem(inv, 291, 43, 1, 43, "&aHat 43", "");
		utils.createItem(inv, 291, 44, 1, 44, "&aHat 44", "");
		utils.createItem(inv, 291, 45, 1, 45, "&aHat 45", "");
		
		// Next Page
		utils.createItem(inv, 339, 0, 1, 54, "&aPage 2", "");
		
		
		toReturn.setContents(inv.getContents());
		
		return toReturn;
	}
	
	public static void clicked(Player p, int slot, ItemStack clicked, Inventory inv) {
		if (clicked.getItemMeta().getDisplayName().equalsIgnoreCase(utils.chat("&aPage 2"))) {
			p.closeInventory();
			p.openInventory(HatsMenu2.GUI(p));
		}
		if (!clicked.getItemMeta().getDisplayName().equalsIgnoreCase(utils.chat("&aPage 2"))) {
			p.getInventory().setHelmet(inv.getItem(slot));
			p.closeInventory();
			p.sendMessage(utils.chat("&8[&eHats&8] &8> &aSelected ") + clicked.getItemMeta().getDisplayName());
		}
		
	}

}

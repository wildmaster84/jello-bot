package ga.foreverroleplay.GUI;


import org.bukkit.Bukkit;
import org.bukkit.entity.Player;
import org.bukkit.inventory.*;

import ga.foreverroleplay.utils.utils;

public class HatsMenu2 {
	
	public static Inventory inv;
	public static String inventory_name;
	public static int inv_rows = 6 * 9;
	
	public static void initialize() {
		inventory_name = utils.chat("&8Hats  (Page 2)");
		
		inv = Bukkit.createInventory(null, inv_rows);
	}
	public static Inventory GUI(Player p) {
		Inventory toReturn = Bukkit.createInventory(null, inv_rows, inventory_name);
		//Add inv items here!
		//               inv  ID  Stack Slot  name  Lore
		utils.createItem(inv, 291, 46, 1, 1, "&aHat 46", "");
		utils.createItem(inv, 291, 47, 1, 2, "&aHat 47", "");
		utils.createItem(inv, 291, 48, 1, 3, "&aHat 48", "");
		utils.createItem(inv, 291, 49, 1, 4, "&aHat 49", "");
		utils.createItem(inv, 291, 50, 1, 5, "&aHat 50", "");
		utils.createItem(inv, 291, 51, 1, 6, "&aHat 51", "");
		utils.createItem(inv, 291, 52, 1, 7, "&aHat 52", "");
		utils.createItem(inv, 291, 53, 1, 8, "&aHat 53", "");
		utils.createItem(inv, 291, 54, 1, 9, "&aHat 54", "");
		utils.createItem(inv, 291, 55, 1, 10, "&aHat 55", "");
		utils.createItem(inv, 291, 56, 1, 11, "&aHat 56", "");
		utils.createItem(inv, 291, 57, 1, 12, "&aHat 57", "");
		utils.createItem(inv, 291, 58, 1, 13, "&aHat 58", "");
		utils.createItem(inv, 291, 59, 1, 14, "&aHat 59", "");
		utils.createItem(inv, 291, 60, 1, 15, "&aHat 60", "");
		utils.createItem(inv, 291, 61, 1, 16, "&aHat 61", "");
		utils.createItem(inv, 291, 62, 1, 17, "&aHat 62", "");
		utils.createItem(inv, 291, 63, 1, 18, "&aHat 63", "");
		utils.createItem(inv, 291, 64, 1, 19, "&aHat 64", "");
		utils.createItem(inv, 291, 65, 1, 20, "&aHat 65", "");
		utils.createItem(inv, 291, 66, 1, 21, "&aHat 66", "");
		utils.createItem(inv, 291, 67, 1, 22, "&aHat 67", "");
		utils.createItem(inv, 291, 68, 1, 23, "&aHat 68", "");
		utils.createItem(inv, 291, 69, 1, 24, "&aHat 69", "");
		utils.createItem(inv, 291, 70, 1, 25, "&aHat 70", "");
		utils.createItem(inv, 291, 71, 1, 26, "&aHat 71", "");
		utils.createItem(inv, 291, 72, 1, 27, "&aHat 72", "");
		utils.createItem(inv, 291, 73, 1, 28, "&aHat 73", "");
		utils.createItem(inv, 291, 74, 1, 29, "&aHat 74", "");
		utils.createItem(inv, 291, 75, 1, 30, "&aHat 75", "");
		utils.createItem(inv, 291, 76, 1, 31, "&aHat 76", "");
		utils.createItem(inv, 291, 77, 1, 32, "&aHat 77", "");
		utils.createItem(inv, 291, 78, 1, 33, "&aHat 78", "");
		utils.createItem(inv, 291, 79, 1, 34, "&aHat 79", "");
		utils.createItem(inv, 291, 80, 1, 35, "&aHat 80", "");
		utils.createItem(inv, 291, 81, 1, 36, "&aHat 81", "");
		utils.createItem(inv, 291, 82, 1, 37, "&aHat 82", "");
		utils.createItem(inv, 291, 83, 1, 38, "&aHat 83", "");
		utils.createItem(inv, 291, 84, 1, 39, "&aHat 84", "");
		utils.createItem(inv, 291, 85, 1, 40, "&aHat 85", "");
		utils.createItem(inv, 291, 86, 1, 41, "&aHat 86", "");
		utils.createItem(inv, 291, 87, 1, 42, "&aHat 87", "");
		utils.createItem(inv, 291, 88, 1, 43, "&aHat 88", "");
		utils.createItem(inv, 291, 89, 1, 44, "&aHat 89", "");
		utils.createItem(inv, 291, 90, 1, 45, "&aHat 90", "");
		
		
		
		// Next Page		
		utils.createItem(inv, 339, 0, 1, 46, "&aPage 1", "");
		
		
		toReturn.setContents(inv.getContents());
		
		return toReturn;
	}
	
	public static void clicked(Player p, int slot, ItemStack clicked, Inventory inv) {
		if (clicked.getItemMeta().getDisplayName().equalsIgnoreCase(utils.chat("&aPage 1"))) {
			p.closeInventory();
			p.openInventory(HatsMenu.GUI(p));
		}
		if (!clicked.getItemMeta().getDisplayName().equalsIgnoreCase(utils.chat("&aPage 1"))) {
			p.getInventory().setHelmet(inv.getItem(slot));
			p.closeInventory();
			p.sendMessage(utils.chat("&8[&eHats&8] &7> &aSelected ") + clicked.getItemMeta().getDisplayName());
		}	
	}

}

package ga.foreverroleplay.GUI;

import org.bukkit.Bukkit;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.entity.Player;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.ItemStack;
import ga.foreverroleplay.foreverpack.Main;

import ga.foreverroleplay.utils.utils;

public class EarsMenu {
	
	public static Inventory inv;
	public static String inventory_name;
	public static int inv_rows = 6 * 9;
	
	public static void initialize() {
		inventory_name = utils.chat("&8Ears  (Page 1)");
		
		inv = Bukkit.createInventory(null, inv_rows);
	}
	public static Inventory GUI(Player p) {
		Inventory toReturn = Bukkit.createInventory(null, inv_rows, inventory_name);
		//Add inv items here!
		
		// Loop Items
		utils.createItem(inv, 290, 1, 1, 1, "&aEars 1", "");
		utils.createItem(inv, 290, 2, 1, 2, "&aEars 2", "");
		utils.createItem(inv, 290, 3, 1, 3, "&aEars 3", "");
		utils.createItem(inv, 290, 4, 1, 4, "&aEars 4", "");
		utils.createItem(inv, 290, 5, 1, 5, "&aEars 5", "");
		utils.createItem(inv, 290, 6, 1, 6, "&aEars 6", "");
		utils.createItem(inv, 290, 7, 1, 7, "&aEars 7", "");
		utils.createItem(inv, 290, 8, 1, 8, "&aEars 8", "");
		utils.createItem(inv, 290, 9, 1, 9, "&aEars 9", "");
		utils.createItem(inv, 290, 10, 1, 10, "&aEars 10", "");
		utils.createItem(inv, 290, 11, 1, 11, "&aEars 11", "");
		utils.createItem(inv, 290, 12, 1, 12, "&aEars 12", "");
		utils.createItem(inv, 290, 13, 1, 13, "&aEars 13", "");
		utils.createItem(inv, 290, 14, 1, 14, "&aEars 14", "");
		utils.createItem(inv, 290, 15, 1, 15, "&aEars 15", "");
		utils.createItem(inv, 290, 16, 1, 16, "&aEars 16", "");
		utils.createItem(inv, 290, 17, 1, 17, "&aEars 17", "");
		utils.createItem(inv, 290, 18, 1, 18, "&aEars 18", "");
		utils.createItem(inv, 290, 19, 1, 19, "&aEars 19", "");
		utils.createItem(inv, 290, 20, 1, 20, "&aEars 20", "");
		utils.createItem(inv, 290, 21, 1, 21, "&aEars 21", "");
		utils.createItem(inv, 290, 22, 1, 22, "&aEars 22", "");
		utils.createItem(inv, 290, 23, 1, 23, "&aEars 23", "");
		utils.createItem(inv, 290, 24, 1, 24, "&aEars 24", "");
		utils.createItem(inv, 290, 25, 1, 25, "&aEars 25", "");
		utils.createItem(inv, 290, 26, 1, 26, "&aEars 26", "");
		utils.createItem(inv, 290, 27, 1, 27, "&aEars 27", "");
		utils.createItem(inv, 290, 28, 1, 28, "&aEars 28", "");
		utils.createItem(inv, 290, 29, 1, 29, "&aEars 29", "");
		utils.createItem(inv, 290, 30, 1, 30, "&aEars 30", "");
		utils.createItem(inv, 290, 31, 1, 31, "&aEars 31", "");
		utils.createItem(inv, 290, 32, 1, 32, "&aEars 32", "");
		utils.createItem(inv, 290, 33, 1, 33, "&aEars 33", "");
		utils.createItem(inv, 290, 34, 1, 34, "&aEars 34", "");
		utils.createItem(inv, 290, 35, 1, 35, "&aEars 35", "");
		utils.createItem(inv, 290, 36, 1, 36, "&aEars 36", "");
		utils.createItem(inv, 290, 37, 1, 37, "&aEars 37", "");
		utils.createItem(inv, 290, 38, 1, 38, "&aEars 38", "");
		utils.createItem(inv, 290, 39, 1, 39, "&aEars 39", "");
		utils.createItem(inv, 290, 40, 1, 40, "&aEars 40", "");
		utils.createItem(inv, 290, 41, 1, 41, "&aEars 41", "");
		utils.createItem(inv, 290, 42, 1, 42, "&aEars 42", "");
		utils.createItem(inv, 290, 43, 1, 43, "&aEars 43", "");
		utils.createItem(inv, 290, 44, 1, 44, "&aEars 44", "");
		utils.createItem(inv, 290, 45, 1, 45, "&aEars 45", "");
		
		// Next Page
		utils.createItem(inv, 339, 0, 1, 54, "&aPage 2", "");
		
		
		toReturn.setContents(inv.getContents());
		
		return toReturn;
	}
	
	public static void clicked(Player p, int slot, ItemStack clicked, Inventory inv) {
		if (clicked.getItemMeta().getDisplayName().equalsIgnoreCase(utils.chat("&aPage 2"))) {
			p.closeInventory();
			p.openInventory(EarsMenu2.GUI(p));
		}
		if (!clicked.getItemMeta().getDisplayName().equalsIgnoreCase(utils.chat("&aPage 2"))) {
			p.getInventory().setHelmet(inv.getItem(slot));
			p.closeInventory();
			p.sendMessage(utils.chat("&8[&eEars&8] &7> &aSelected ") + clicked.getItemMeta().getDisplayName());
		}
		
	}

}
